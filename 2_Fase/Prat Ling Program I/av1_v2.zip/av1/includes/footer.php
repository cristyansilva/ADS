</div> <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const titleElement = document.querySelector('h1.page-title');
        const titleContainer = document.getElementById('page-title-container');
        if (titleElement && titleContainer) {
            titleContainer.appendChild(titleElement);
        }
    });
</script>
</body>
</html>